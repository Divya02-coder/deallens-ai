"""
DealLens semantic retrieval layer.
"""